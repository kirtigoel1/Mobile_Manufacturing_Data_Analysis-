use db_SQLCaseStudies

-- SQl Advance case study

--Q1--BEGIN

select state, F.date
from dim_location as L
join
fact_transactions as F
on L.IdLocation = F.Idlocation
where F.date  >= '2005-01-01' and F.date <=  getdate();

--Q1--END

--Q2--BEGIN

SELECT top 1 country, state,
count(*) as no_of_cellphones
FROM DIM_LOCATION AS L
JOIN
FACT_TRANSACTIONS AS F
ON L.IDLocation = F.IDLocation
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
JOIN
DIM_MANUFACTURER AS N
ON M.IDManufacturer = N.IDManufacturer
where Manufacturer_name = 'Samsung' and country = 'US'
group by country, state
order by 3 desc;

--Q2-- End

--Q3--Begin

select Model_Name, ZipCode, L.State,
count(*) as no_of_transactions
FROM DIM_LOCATION AS L
JOIN
FACT_TRANSACTIONS AS F
ON L.IDLocation = F.IDLocation
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
group by M.Model_Name,ZipCode, L.State;

--Q3--End

--Q4--Begin

select TOP 1 Manufacturer_Name, MODEL_NAME, UNIT_PRICE
from DIM_MODEL as M
join 
DIM_MANUFACTURER as N
on M.IDManufacturer = N.IDManufacturer
ORDER BY 3;

--Q4--End

--Q5--Begin

SELECT Manufacturer_Name, MODEL_NAME , AVG(uNIT_PRICE) AS aVG_PRICE FROM
FACT_TRANSACTIONS AS F
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
JOIN
DIM_MANUFACTURER AS N
ON M.IDManufacturer = N.IDManufacturer
WHERE Manufacturer_Name IN 
 (select top 5 Manufacturer_Name from
FACT_TRANSACTIONS AS F
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
JOIN
DIM_MANUFACTURER AS N
ON M.IDManufacturer = N.IDManufacturer
group by Manufacturer_Name
order by sum(TotalPrice) desc)
GROUP BY Manufacturer_Name, Model_Name
ORDER BY 3 DESC;

--Q5--End

--Q6--Begin

select Customer_Name, avg(totalprice)as total_price from DIM_CUSTOMER as C
join FACT_TRANSACTIONS as T
on C.IDCustomer = T.IDCustomer
where year(T.date) = 2009
group by Customer_Name
having avg(totalprice) > 500

--Q6--End

--Q7--Begin

select model_name from
 (SELECT model_name,
YEAR(date) AS year, quantity,
RANK() OVER (PARTITION BY YEAR(date) ORDER BY quantity DESC) AS rank_within_year
from
FACT_TRANSACTIONS AS F
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
WHERE YEAR(date) IN (2008, 2009, 2010)) as ranked_table
WHERE rank_within_year <= 5
GROUP BY model_name
HAVING COUNT(DISTINCT year) = 3;

--Q7--End  
   
--Q8--Begin

select  manufacturer_name, Year1 as _Year, total_sales
from
(SELECT manufacturer_name, Year1, total_sales,
RANK() over(partition by YEAR1 order by total_sales desc) AS RANK_WITHIN_YEAR
FROM
(select manufacturer_name,
YEAR( f.DATE) AS YEAR1,
sum(totalprice) as total_sales
from
 FACT_TRANSACTIONS AS F
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
JOIN
DIM_MANUFACTURER AS N
ON M.IDManufacturer = N.IDManufacturer
where Year(f.date) in (2009,2010)
group by Manufacturer_Name, YEAR( f.DATE)) AS RANKED_TABLE) as T
where RANK_WITHIN_YEAR = 2

--Q8--End

--Q9--Begin

SELECT DISTINCT Manufacturer_Name
 from
 FACT_TRANSACTIONS AS F
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
JOIN
DIM_MANUFACTURER AS N
ON M.IDManufacturer = N.IDManufacturer
WHERE YEAR(DATE) = 2010
EXCEPT
SELECT DISTINCT Manufacturer_Name
 from
 FACT_TRANSACTIONS AS F
JOIN 
DIM_MODEL AS M
ON F.IDModel = M.IDModel
JOIN
DIM_MANUFACTURER AS N
ON M.IDManufacturer = N.IDManufacturer
WHERE YEAR(DATE) = 2009

--Q9--END

--Q10--Begin

select Customer_Name, _year, avg_sales, avg_qty, 
((avg_sales - lag_value)/lag_value)*100 as percent_change
from
(select *,
lag(avg_sales,1) over (partition by customer_name order by _year) as lag_value
from
(select year(t.date) as _year, Customer_Name , Avg(totalprice) as avg_sales, avg(quantity) as avg_qty
from  DIM_CUSTOMER as C
join FACT_TRANSACTIONS as T
on C.IDCustomer = T.IDCustomer
where Customer_Name in (SELECT top 10 C.Customer_Name
from DIM_CUSTOMER as C
join FACT_TRANSACTIONS as T
on C.IDCustomer = T.IDCustomer
group by Customer_Name
order by sum(T.totalprice) desc ) 
group by year(t.date) ,Customer_Name) as T1 ) as T2

--Q10--END
